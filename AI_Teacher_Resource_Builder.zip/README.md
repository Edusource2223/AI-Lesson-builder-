
# AI Teacher Resource Builder

This is an AI-powered tool for generating lesson plans, quizzes, worksheets, slide outlines, and reading passages for teachers.

## How to Run

1. Install dependencies:
   pip install -r requirements.txt

2. Add your OpenAI API key:
   In `.streamlit/secrets.toml`:
   [OPENAI]
   OPENAI_API_KEY = "your_api_key_here"

3. Run the app:
   streamlit run teacher_ai_app.py
