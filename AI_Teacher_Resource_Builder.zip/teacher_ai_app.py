
import streamlit as st
import openai
import requests
import base64

# Set your OpenAI API Key
openai.api_key = st.secrets["OPENAI_API_KEY"]

st.set_page_config(page_title="AI Teacher Resource Builder", layout="wide")
st.title("AI-Powered Teacher Resource Builder")

# Sidebar Navigation
st.sidebar.title("Navigation")
page = st.sidebar.radio("Select a resource type:", [
    "Lesson Plan", "Quiz", "Worksheet", "Slide Outline", "Reading Passage"
])

# Common Inputs
st.sidebar.title("Resource Settings")
subject = st.sidebar.text_input("Subject", "Science")
grade_level = st.sidebar.selectbox("Grade Level", [str(i) for i in range(1, 13)])
topic = st.sidebar.text_input("Topic", "Ecosystems")
difficulty = st.sidebar.selectbox("Difficulty Level", ["Basic", "Intermediate", "Advanced"])
curriculum = st.sidebar.selectbox("Curriculum Alignment (Optional)", ["None", "Common Core", "NGSS", "IB Curriculum", "Cambridge", "Local Standard"])

# Quiz-specific options
if page == "Quiz":
    num_questions = st.sidebar.slider("Number of Questions", 3, 20, 10)
    question_difficulty = st.sidebar.selectbox("Question Difficulty Focus", ["Mixed", "Easy", "Moderate", "Challenging"])
    include_answer_key = st.sidebar.checkbox("Include Answer Key", value=True)
    include_blooms = st.sidebar.checkbox("Include Bloom’s Taxonomy Level", value=False)

# Image generation
with st.expander("Need a diagram or image for this lesson/topic?"):
    generate_image = st.checkbox("Generate an image for this topic")
    image_description = st.text_input("Image Description", f"{topic} illustration for grade {grade_level} {subject} class")
    if generate_image and st.button("Generate Image"):
        with st.spinner("Creating your image..."):
            image_response = openai.Image.create(
                prompt=image_description,
                n=1,
                size="512x512"
            )
            image_url = image_response["data"][0]["url"]
            st.image(image_url, caption="Generated Educational Image")
            img_data = requests.get(image_url).content
            b64 = base64.b64encode(img_data).decode()
            href = f'<a href="data:file/jpg;base64,{b64}" download="{topic}_image.jpg">Download Image</a>'
            st.markdown(href, unsafe_allow_html=True)

# Prompt templates
def generate_prompt(page, subject, grade_level, topic, difficulty, curriculum):
    alignment = f" Align it with {curriculum} standards." if curriculum != "None" else ""
    return f"Generate a {page.lower()} for a grade {grade_level} {subject} class. Topic: {topic}. Difficulty Level: {difficulty}.{alignment} Make it clear, structured, and directly usable by a teacher."

def generate_quiz_prompt(subject, grade_level, topic, difficulty, num_questions, question_difficulty, include_answer_key, include_blooms, curriculum):
    alignment = f" Align the questions with {curriculum} standards." if curriculum != "None" else ""
    key_instruction = " Include an answer key at the end." if include_answer_key else ""
    blooms_instruction = " Label each question with its Bloom's Taxonomy level." if include_blooms else ""
    return f"Generate a quiz for a grade {grade_level} {subject} class on the topic of '{topic}'. Total Questions: {num_questions}. Overall difficulty: {difficulty}. Question difficulty focus: {question_difficulty}. Format clearly with numbered questions.{key_instruction}{blooms_instruction}{alignment}"

# Generate button
if st.button("Generate Resource"):
    with st.spinner("Generating content..."):
        if page == "Quiz":
            prompt = generate_quiz_prompt(subject, grade_level, topic, difficulty, num_questions, question_difficulty, include_answer_key, include_blooms, curriculum)
        else:
            prompt = generate_prompt(page, subject, grade_level, topic, difficulty, curriculum)
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are an expert teaching assistant that builds classroom resources for teachers."},
                {"role": "user", "content": prompt}
            ]
        )
        result = response['choices'][0]['message']['content']
        st.subheader(f"{page} for Grade {grade_level} - {topic}")
        st.write(result)
        st.download_button("Download as Text File", result, file_name=f"{page}_{topic}.txt")
